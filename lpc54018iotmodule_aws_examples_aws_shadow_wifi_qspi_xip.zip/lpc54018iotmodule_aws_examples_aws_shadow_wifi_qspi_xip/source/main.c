/*
 * The Clear BSD License
 * Copyright (c) 2013 - 2014, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided
 * that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * Amazon FreeRTOS V1.0.0
 * Copyright (C) 2017 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software. If you wish to use our Amazon
 * FreeRTOS name, please do so in a fair use way that does not cause confusion.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * http://aws.amazon.com/freertos
 * http://www.FreeRTOS.org
 */

///////////////////////////////////////////////////////////////////////////////
//  Includes
///////////////////////////////////////////////////////////////////////////////

/* SDK Included Files */
#include "board.h"
#include "fsl_debug_console.h"

#include "pin_mux.h"

/* Amazon FreeRTOS Demo Includes */
#include "FreeRTOS.h"
#include "task.h"
#include "aws_clientcredential.h"
#include "aws_logging_task.h"
#include "aws_wifi.h"
#include "aws_system_init.h"
#include "aws_dev_mode_key_provisioning.h"

#include <stdbool.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fsl_i2c.h"
#include "fsl_power.h"
//#include "usb_device_config.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define EXAMPLE_I2C_MASTER_BASE (I2C2_BASE)
#define I2C_MASTER_CLOCK_FREQUENCY (12000000)

#define EXAMPLE_I2C_MASTER ((I2C_Type *)EXAMPLE_I2C_MASTER_BASE)

#define I2C_MASTER_SLAVE_ADDR_7BIT 0x1D
#define I2C_BAUDRATE 100000U
#define I2C_DATA_LENGTH 7U
#define I2C_DATA_LENGTH_RX 7


#define LOGGING_TASK_PRIORITY (tskIDLE_PRIORITY + 1)
#define LOGGING_TASK_STACK_SIZE (200)
#define LOGGING_QUEUE_LENGTH (16)

/*******************************************************************************
 * Variables
 ******************************************************************************/
int16_t xyz[3];
unsigned int data;

uint8_t g_master_txBuff[I2C_DATA_LENGTH];
uint8_t g_master_rxBuff[I2C_DATA_LENGTH_RX];
volatile bool g_MasterCompletionFlag = false;


char messages [10][32];


/*******************************************************************************
 * FUNCIONES
 ******************************************************************************/
void load_messages() {
	strcpy(messages[0],"I - Muy debil.");
	//Perceptible solo por algunas personas en reposo, particularmente aquellas que se encuentran ubicadas en los pisos superiores de los edificios. Los objetos colgantes suelen oscilar. Aceleración entre 0,5 y 2,5 Gal.3?4?
	strcpy(messages[1],"II/III - Leve.");
	//Perceptible por algunas personas dentro de los edificios, especialmente en pisos altos. Muchos no lo perciben como un terremoto. Los automóviles detenidos se mueven ligeramente. Sensación semejante al paso de un camión pequeño. Aceleración entre 2,5 y 6,0 Gal.3?4?
	strcpy(messages[2],"IV - Moderado.");
	//Perceptible por la mayoría de personas dentro de los edificios, por pocas personas en el exterior durante el día. Durante la noche algunas personas pueden despertarse. Perturbación en cerámica, puertas y ventanas. Las paredes suelen hacer ruido. Los automóviles detenidos se mueven con más energía. Sensación semejante al paso de un camión grande. Aceleración entre 6,0 y 10 Gal.3?4?
	strcpy(messages[3],"V - Poco fuerte.");
	//Sacudida sentida casi por todo el país o zona y algunas piezas de vajilla o cristales de ventanas se rompen; pocos casos de agrietamiento de aplanados; caen objetos inestables. Se observan perturbaciones en los árboles, postes y otros objetos altos. Se detienen los relojes de péndulo. Aceleración entre 10 y 20 Gal.3?4?
	strcpy(messages[4],"VI - Fuerte.");
	//Sacudida sentida por todo el país o zona. Algunos muebles pesados cambian de sitio y provoca daños leves, en especial en viviendas de material ligero. Aceleración entre 20 y 35 Gal.3?4?
	strcpy(messages[5],"VII - Muy fuerte.");
	//Ponerse de pie es difícil. Muebles dañados. Daños insignificantes en estructuras de buen diseño y construcción. Daños leves a moderados en estructuras ordinarias bien construidas. Daños considerables en estructuras pobremente construidas. Mampostería dañada. Perceptible por personas en vehículos en movimiento. Aceleración entre 35 y 60 Gal.3?4?
	strcpy(messages[6],"VIII - Destructivo.");
	//Daños leves en estructuras especializadas. Daños considerables en estructuras ordinarias bien construidas, posibles derrumbes. Fuertes daños en estructuras pobremente construidas. Mampostería seriamente dañada o destruida. Muebles completamente sacados de lugar. Aceleración entre 60 y 100 Gal.3?4?
	strcpy(messages[7],"IX - Muy destructivo.");
	//Pánico generalizado. Daños considerables en estructuras especializadas, paredes fuera de plomo. Grandes daños en importantes edificios, con derrumbes parciales. Edificios desplazados fuera de las bases. Aceleración entre 100 y 250 Gal.3?4?
	strcpy(messages[8],"X+ - Desastroso");
	//Algunas estructuras de madera bien construidas quedan destruidas. La mayoría de las estructuras de mampostería y el marco destruido con sus bases. Vías ferroviarias dobladas. Aceleración entre 250 y 500 Gal.3?4?
}

/*
M      sg
I      < 0.0017
II-III 0.0017 - 0.014
IV     0.014 - 0.039
V      0.039 - 0.092
VI     0.092 - 0.18
VII    0.18 - 0.34
VIII   0.34 - 0.65
IX     0.65 - 1.24
X+     > 1.24
 */

unsigned int mercalli_seism_alert(unsigned int data) {
	/* 0.98mg;12 bit resolution, 0111.. 1.999, 1111.. -1.999 */
	unsigned int data_int;
	float seismic_acceleration = 0.0;
	float sign = 1.0;
	data_int  = data & 0x00000fff;
	unsigned int mercalli = 0;
	/* detect sign */
	if (0x00000800 & data_int) {
		sign  = -1.0;
	}
	/* clculate seismic acceleration */
	data_int &= 0x000007ff;
	seismic_acceleration = sign * 0.00098 * ((float)data_int);
	/* assign mercalli scale */
	if (seismic_acceleration < 0.0017) {
		mercalli = 1;
	} else if (0.0017 <= seismic_acceleration && seismic_acceleration < 0.014) {
		mercalli = 23;
	} else if (0.014 <= seismic_acceleration && seismic_acceleration < 0.039){
		mercalli = 4;
	} else if (0.039 <= seismic_acceleration && seismic_acceleration < 0.092){
		mercalli = 5;
	} else if (0.092 <= seismic_acceleration && seismic_acceleration < 0.18){
		mercalli = 6;
	} else if (0.18 <= seismic_acceleration && seismic_acceleration < 0.34){
		mercalli = 7;
	} else if (0.34 <= seismic_acceleration && seismic_acceleration < 0.65){
		mercalli = 8;
	} else if (0.65 <= seismic_acceleration && seismic_acceleration < 1.24){
		mercalli = 9;
	} else if (1.24 <= seismic_acceleration){
		mercalli = 10;
	}
	//printf("Data: %u, Data_int: %u, Data_float: %f, mercalli: %d\n",
	//    data,data_int,seismic_acceleration,mercalli);
	return mercalli;
}

void send_alert(unsigned int mercalli) {
	switch(mercalli) {
	case 1:
		printf("%s\n",messages[0]);
		break;
	case 23:
		printf("%s\n",messages[1]);
		break;
	case 4:
		printf("%s\n",messages[2]);
		break;
	case 5:
		printf("%s\n",messages[3]);
		break;
	case 6:
		printf("%s\n",messages[4]);
		break;
	case 7:
		printf("%s\n",messages[5]);
		break;
	case 8:
		printf("%s\n",messages[6]);
		break;
	case 9:
		printf("%s\n",messages[7]);
		break;
	default:
		printf("%s\n",messages[8]);
		break;
	}
}

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
extern void vStartShadowDemoTasks(void);
static int prvWifiConnect(void);

/*******************************************************************************
 * Code
 ******************************************************************************/
const WIFINetworkParams_t pxNetworkParams = {
		.pcSSID = clientcredentialWIFI_SSID,
		.pcPassword = clientcredentialWIFI_PASSWORD,
		.xSecurity = clientcredentialWIFI_SECURITY,
};

void vApplicationDaemonTaskStartupHook(void)
{
	/* A simple example to demonstrate key and certificate provisioning in
	 * microcontroller flash using PKCS#11 interface. This should be replaced
	 * by production ready key provisioning mechanism. */
	vDevModeKeyProvisioning();

	if (SYSTEM_Init() == pdPASS)
	{
		if (prvWifiConnect())
		{
			configPRINTF(("Failed to connect to wifi, stopping demo.\r\n"));
			vTaskDelete(NULL);
		}
		else
		{
			vStartShadowDemoTasks();
		}
	}
}

int main(void)
{

	///////////////////////////////////
	unsigned int ret;
	unsigned int mercalli;
	//////////////////////////////////
	i2c_master_config_t masterConfig;
	status_t reVal = kStatus_Fail;


	/* attach 12 MHz clock to FLEXCOMM0 (debug console) */
	CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);

	/* attach 12 MHz clock to FLEXCOMM2 (I2C master) */
	CLOCK_AttachClk(kFRO12M_to_FLEXCOMM2);

	/* reset FLEXCOMM2 for I2C */
	RESET_PeripheralReset(kFC2_RST_SHIFT_RSTn);

	/* reset USB0 and USB1 device */
	RESET_PeripheralReset(kUSB0D_RST_SHIFT_RSTn);
	RESET_PeripheralReset(kUSB1D_RST_SHIFT_RSTn);
	RESET_PeripheralReset(kUSB0HMR_RST_SHIFT_RSTn);
	RESET_PeripheralReset(kUSB0HSL_RST_SHIFT_RSTn);
	RESET_PeripheralReset(kUSB1H_RST_SHIFT_RSTn);

	NVIC_ClearPendingIRQ(USB0_IRQn);
	NVIC_ClearPendingIRQ(USB0_NEEDCLK_IRQn);
	NVIC_ClearPendingIRQ(USB1_IRQn);
	NVIC_ClearPendingIRQ(USB1_NEEDCLK_IRQn);

	BOARD_InitPins();
	BOARD_BootClockFROHF96M();
	//BOARD_InitDebugConsole();

#if (defined USB_DEVICE_CONFIG_LPCIP3511HS) && (USB_DEVICE_CONFIG_LPCIP3511HS)
	POWER_DisablePD(kPDRUNCFG_PD_USB1_PHY);
	/* enable usb1 host clock */
	CLOCK_EnableClock(kCLOCK_Usbh1);
	*((uint32_t *)(USBHSH_BASE + 0x50)) |= USBHSH_PORTMODE_DEV_ENABLE_MASK;
	/* enable usb1 host clock */
	CLOCK_DisableClock(kCLOCK_Usbh1);
#endif
#if (defined USB_DEVICE_CONFIG_LPCIP3511FS) && (USB_DEVICE_CONFIG_LPCIP3511FS)
	POWER_DisablePD(kPDRUNCFG_PD_USB0_PHY); /*< Turn on USB Phy */
	CLOCK_SetClkDiv(kCLOCK_DivUsb0Clk, 1, false);
	CLOCK_AttachClk(kFRO_HF_to_USB0_CLK);
	/* enable usb0 host clock */
	CLOCK_EnableClock(kCLOCK_Usbhsl0);
	*((uint32_t *)(USBFSH_BASE + 0x5C)) |= USBFSH_PORTMODE_DEV_ENABLE_MASK;
	/* disable usb0 host clock */
	CLOCK_DisableClock(kCLOCK_Usbhsl0);
#endif

	BOARD_InitDebugConsole();

	PRINTF("\r\nI2C board2board polling example -- Master transfer.\r\n");

	I2C_MasterGetDefaultConfig(&masterConfig);

	/* Change the default baudrate configuration */
	masterConfig.baudRate_Bps = I2C_BAUDRATE;

	/* Initialize the I2C master peripheral */
	I2C_MasterInit(EXAMPLE_I2C_MASTER, &masterConfig, I2C_MASTER_CLOCK_FREQUENCY);

	//Send master blocking data to slave
	if (kStatus_Success == I2C_MasterStart(EXAMPLE_I2C_MASTER, I2C_MASTER_SLAVE_ADDR_7BIT, kI2C_Write))
	{
		g_master_txBuff[0] = 0x2A;//I2C_DATA_LENGTH - 1U; // STATUS REGISTER 0x2A
		g_master_txBuff[1] = 0x00;//0X00//0D

		reVal = I2C_MasterWriteBlocking(EXAMPLE_I2C_MASTER, g_master_txBuff, 2U, 0);
		if (reVal != kStatus_Success)
		{
			return -1;
		}
		reVal = I2C_MasterStop(EXAMPLE_I2C_MASTER);
		if (reVal != kStatus_Success)
		{
			return -1;
		}
	}

	//Send master blocking data to slave
	if (kStatus_Success == I2C_MasterStart(EXAMPLE_I2C_MASTER, I2C_MASTER_SLAVE_ADDR_7BIT, kI2C_Write))
	{

		g_master_txBuff[0] = 0x0E;
		g_master_txBuff[1] = 0x00;

		reVal = I2C_MasterWriteBlocking(EXAMPLE_I2C_MASTER, g_master_txBuff, 2U, 0);
		if (reVal != kStatus_Success)
		{
			return -1;
		}

		reVal = I2C_MasterStop(EXAMPLE_I2C_MASTER);
		if (reVal != kStatus_Success)
		{
			return -1;
		}
	}

	if (kStatus_Success == I2C_MasterStart(EXAMPLE_I2C_MASTER, I2C_MASTER_SLAVE_ADDR_7BIT, kI2C_Write))
	{

		g_master_txBuff[0] = 0x2A;
		g_master_txBuff[1] = 0x21;

		reVal = I2C_MasterWriteBlocking(EXAMPLE_I2C_MASTER, g_master_txBuff, 2U, 0);
		if (reVal != kStatus_Success)
		{
			return -1;
		}
		reVal = I2C_MasterStop(EXAMPLE_I2C_MASTER);
		if (reVal != kStatus_Success)
		{
			return -1;
		}
	}

	///////////////////////////////////////////////////////////////////////////
	//READING WHO I AM
	uint8_t deviceAddress = 0x0D;
	if (kStatus_Success == I2C_MasterStart(EXAMPLE_I2C_MASTER, I2C_MASTER_SLAVE_ADDR_7BIT, kI2C_Write))
	{
		//subAddress = 0x01, data = g_master_txBuff - write to slave.
		//start + slaveaddress(w) + subAddress + length of data buffer + data buffer + stop
		reVal = I2C_MasterWriteBlocking(EXAMPLE_I2C_MASTER, &deviceAddress, 1, kI2C_TransferNoStopFlag);
		if (reVal != kStatus_Success)
		{
			return -1;
		}

		reVal = I2C_MasterRepeatedStart(EXAMPLE_I2C_MASTER, I2C_MASTER_SLAVE_ADDR_7BIT, kI2C_Read);
		if (reVal != kStatus_Success)
		{
			return -1;
		}

		reVal = I2C_MasterReadBlocking(EXAMPLE_I2C_MASTER, g_master_rxBuff, 1, 0);
		if (reVal != kStatus_Success)
		{
			return -1;
		}
		reVal = I2C_MasterStop(EXAMPLE_I2C_MASTER);
		if (reVal != kStatus_Success)
		{
			return -1;
		}
	}
	while (1)
	{

		if (kStatus_Success == I2C_MasterStart(EXAMPLE_I2C_MASTER, I2C_MASTER_SLAVE_ADDR_7BIT, kI2C_Write))
		{

			g_master_txBuff[0] = 0x00;//I2C_DATA_LENGTH - 1U; // STATUS REGISTER
			g_master_txBuff[1] = 0x00;//I2C_DATA_LENGTH - 1U; // STATUS REGISTER

			reVal = I2C_MasterWriteBlocking(EXAMPLE_I2C_MASTER, g_master_txBuff, 1U, 0);
			if (reVal != kStatus_Success)
			{
				return -1;
			}

			reVal = I2C_MasterRepeatedStart(EXAMPLE_I2C_MASTER, I2C_MASTER_SLAVE_ADDR_7BIT, kI2C_Read);
			if (reVal != kStatus_Success)
			{
				return -1;
			}
			reVal = I2C_MasterReadBlocking(EXAMPLE_I2C_MASTER, g_master_rxBuff, 7U, 0);
			if (reVal != kStatus_Success)
			{
				return -1;
			}
			reVal = I2C_MasterStop(EXAMPLE_I2C_MASTER);
			if (reVal != kStatus_Success)
			{
				return -1;
			}

			//g_master_rxBuff
			//xyz
			xyz[0] = ((g_master_rxBuff[1] * 256) + ((unsigned short) g_master_rxBuff[2]));
			xyz[1] = ((g_master_rxBuff[3] * 256) + ((unsigned short) g_master_rxBuff[4]));
			xyz[2] = ((g_master_rxBuff[5] * 256) + ((unsigned short) g_master_rxBuff[6]));

			data = sqrt(((xyz[0])^2)+((xyz[1])^2)+((xyz[2])^2));

			PRINTF("Master rx data :");
			for (uint32_t i = 0U; i < 7 - 1U; i++)
			{
				PRINTF("0x%2x  ", g_master_rxBuff[i+1]);
			}
			PRINTF("\r\n");

			PRINTF("XYZ :");
			for (uint32_t i = 0U; i < 4 - 1U; i++)
			{
				PRINTF("0x%2x  ", xyz[i]);
			}
			PRINTF("\r\n");
			//data
			PRINTF("DATA :");
			for (uint32_t i = 0U; i < 1; i++)
			{
				PRINTF("0x%2x  ", data);
			}
			PRINTF("\r\n");
		}


		/////////////////////////////////////////////////////////

		load_messages();
		mercalli = mercalli_seism_alert(data);
		send_alert(mercalli);
		//return 0;

		////////////////////////////////////////////////////////
		//Clear buf data.
		for (uint32_t i = 0U; i < 7; i++)
		{
			if (g_master_rxBuff[i] != 0x0)
			{
				g_master_rxBuff[i] = 0x0;
			}
		}


	xLoggingTaskInitialize(LOGGING_TASK_STACK_SIZE, LOGGING_TASK_PRIORITY, LOGGING_QUEUE_LENGTH);

	vTaskStartScheduler();
	}
	for (;;)
		;
}

static int prvWifiConnect(void)
{
	WIFIReturnCode_t result;

	configPRINTF(("Starting WiFi...\r\n"));

	result = WIFI_On();
	assert(eWiFiSuccess == result);

	configPRINTF(("WiFi module initialized.\r\n"));

	result = WIFI_ConnectAP(&pxNetworkParams);
	assert(eWiFiSuccess == result);

	configPRINTF(("WiFi connected to AP %s.\r\n", pxNetworkParams.pcSSID));

	uint8_t tmp_ip[4] = {0};
	result = WIFI_GetIP(tmp_ip);
	assert(eWiFiSuccess == result);

	configPRINTF(("IP Address acquired %d.%d.%d.%d\r\n", tmp_ip[0], tmp_ip[1], tmp_ip[2], tmp_ip[3]));

	return result;
}

/* configUSE_STATIC_ALLOCATION is set to 1, so the application must provide an
 * implementation of vApplicationGetIdleTaskMemory() to provide the memory that is
 * used by the Idle task. */
void vApplicationGetIdleTaskMemory(StaticTask_t **ppxIdleTaskTCBBuffer,
		StackType_t **ppxIdleTaskStackBuffer,
		uint32_t *pulIdleTaskStackSize)
{
	/* If the buffers to be provided to the Idle task are declared inside this
	 * function then they must be declared static - otherwise they will be allocated on
	 * the stack and so not exists after this function exits. */
	static StaticTask_t xIdleTaskTCB;
	static StackType_t uxIdleTaskStack[configMINIMAL_STACK_SIZE];

	/* Pass out a pointer to the StaticTask_t structure in which the Idle
	 * task's state will be stored. */
	*ppxIdleTaskTCBBuffer = &xIdleTaskTCB;

	/* Pass out the array that will be used as the Idle task's stack. */
	*ppxIdleTaskStackBuffer = uxIdleTaskStack;

	/* Pass out the size of the array pointed to by *ppxIdleTaskStackBuffer.
	 * Note that, as the array is necessarily of type StackType_t,
	 * configMINIMAL_STACK_SIZE is specified in words, not bytes. */
	*pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
}

/* configUSE_STATIC_ALLOCATION and configUSE_TIMERS are both set to 1, so the
 * application must provide an implementation of vApplicationGetTimerTaskMemory()
 * to provide the memory that is used by the Timer service task. */
void vApplicationGetTimerTaskMemory(StaticTask_t **ppxTimerTaskTCBBuffer,
		StackType_t **ppxTimerTaskStackBuffer,
		uint32_t *pulTimerTaskStackSize)
{
	/* If the buffers to be provided to the Timer task are declared inside this
	 * function then they must be declared static - otherwise they will be allocated on
	 * the stack and so not exists after this function exits. */
	static StaticTask_t xTimerTaskTCB;
	static StackType_t uxTimerTaskStack[configTIMER_TASK_STACK_DEPTH];

	/* Pass out a pointer to the StaticTask_t structure in which the Timer
	 * task's state will be stored. */
	*ppxTimerTaskTCBBuffer = &xTimerTaskTCB;

	/* Pass out the array that will be used as the Timer task's stack. */
	*ppxTimerTaskStackBuffer = uxTimerTaskStack;

	/* Pass out the size of the array pointed to by *ppxTimerTaskStackBuffer.
	 * Note that, as the array is necessarily of type StackType_t,
	 * configTIMER_TASK_STACK_DEPTH is specified in words, not bytes. */
	*pulTimerTaskStackSize = configTIMER_TASK_STACK_DEPTH;
}
/**
 * @brief Warn user if pvPortMalloc fails.
 *
 * Called if a call to pvPortMalloc() fails because there is insufficient
 * free memory available in the FreeRTOS heap.  pvPortMalloc() is called
 * internally by FreeRTOS API functions that create tasks, queues, software
 * timers, and semaphores.  The size of the FreeRTOS heap is set by the
 * configTOTAL_HEAP_SIZE configuration constant in FreeRTOSConfig.h.
 *
 */
void vApplicationMallocFailedHook()
{
	configPRINTF(("ERROR: Malloc failed to allocate memory\r\n"));
}

/**
 * @brief Loop forever if stack overflow is detected.
 *
 * If configCHECK_FOR_STACK_OVERFLOW is set to 1,
 * this hook provides a location for applications to
 * define a response to a stack overflow.
 *
 * Use this hook to help identify that a stack overflow
 * has occurred.
 *
 */
void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName)
{
	portDISABLE_INTERRUPTS();

	/* Loop forever */
	for (;;)
		;
}

void *pvPortCalloc(size_t xSize)
{
	void *pvReturn;

	pvReturn = pvPortMalloc(xSize);
	if (pvReturn != NULL)
	{
		memset(pvReturn, 0x00, xSize);
	}

	return pvReturn;
}
